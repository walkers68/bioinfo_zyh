# II.1 BLAST homework
## 第一题  
第一题筛选  
![](第一题.png)
![](第一题筛选.png)
P值和E值是用来评估序列对比结果的两个统计量。它们帮助研究人员判断一个比对结果是否偶然发生的，还是真正代表了序列之间的相似性。  
**P值**：P值表示的是，在随机情况下，获得一个与给定序列比对得分相等或更高得分的比对结果的可能性。P值越小，序列之间相似性越可能是真实的。  
**E值**：E值是一个修正后的P值，用于考虑多重假设检验的问题。它表示的是在进行数据库搜索时，预期会找到一个或更多具有相同或更高得分的随机匹配的次数。E值越低，表明对比结果越可能是非随机的，两序列的相似性更可能就有相似性。  
## 第二题
我使用两个bash来完成该任务  
bash1：
```
#!/bin/bash
#给定蛋白序列
protein="MSTRSVSSSSYRRMFGGPGTASRPSSSRSYVTTSTRTYSLGSALRPSTSRSLYASSPGGVYATRSSAVRL"
#设定循环初始值
i=0
#开始十次循环
while [ "$i" -lt "10" ];
do
        #设定初始索引
        si=0
        #获取蛋白序列长度并存在L中
        L=${#protein}
        #设定结束索引
        ei=$(($L-1))
        shuffled=""
        for m in `seq $si $ei | shuf `;do
                #打乱蛋白质序列
                shuffled=$shuffled${protein:$m:1}
        done
        #将获得的打乱的序列存在.fastaf格式文件中
        echo ">shuffled_sequence_$i" > "shuffled_sequence_$i.fasta"
        echo "$shuffled" >> "shuffled_sequence_$i.fasta"
        i=$((i+1))
done
echo "shuffle finished"
```  
bash2：
```
#!/bin/bash
#创建blast结果目录
mkdir -p blast_results

#对每对序列进行BLAST比对
for i in {0..9}
do
        for j in {0..9}
        do
                if [ $i -lt $j ]
                then
                        #使用blastp进行比对,将结果存入blast_results/blast_result_*
                        blastp -query "shuffled_sequence_$i.fasta" -subject "shuffled_sequence_$j.fasta" -out "blast_results/blast_result_"$i"_vs_$j" -outfmt 6
                fi
        done
done
```
先运行bash1再运行bash2即可完成任务。  
以下是运行结果  
题目2 运行bash生成fasta文件总览
![题目2 运行bash生成fasta文件总览](题目2%20运行bash生成fasta文件总览.png "题目2 运行bash生成fasta文件总览")
题目2 的生成fasta文件实例  
![](题目2%20的生成fasta文件实例.png)  
题目2 运行bash生成比较文件总览
![](题目2%20运行bash生成比较文件总览.png)  
题目2 blast生成的比较文件实例  
![](题目2%20blast生成的比较文件实例.png)  
## 第三题
1. BLAST在搜索过程中设置了得分阈值，只有当潜在的匹配超过这个阈值时，才会进行更详细的比对。这有助于排除那些不太可能是真实匹配的低得分结果。同时，BLAST也设定了E-value阈值，当E-value过高时可以直接被排除减少不必要的比对
2. BLAST对数据库中的序列进行预处理，先识别出其中的元组并记录这些元组在序列中的位置，并把它们预先记录下来。再在比对序列时先找出能有尽可能多的元组与query对应的序列，然后对各个元组间的小序列进行动态规划从而减少了动态规划的计算量。
3. BLAST寻找邻近的匹配而非完美的匹配。
## 第四题
PAM（Point Accepted Mutation）矩阵是一组用于评估蛋白质序列之间替换关系的评分矩阵。PAM矩阵是基于进化模型构建的，它们反映了在进化过程中氨基酸替换的概率。PAM250是PAM矩阵系列中的一个。
PAM矩阵有两种类型：对称（Symmetric）和非对称（Asymmetric）。
### 对称PAM矩阵
对称PAM矩阵假设两个蛋白质序列是在相同的进化压力下独立进化的。这意味着在评估两个序列之间的替换时，矩阵对氨基酸A替换为氨基酸B的评分与氨基酸B替换为氨基酸A的评分是相同的。对称PAM矩阵适用于比较两个序列的相似性，而不考虑它们的进化关系或方向。
### 非对称PAM矩阵
非对称PAM矩阵则考虑了序列之间的进化关系和方向。它基于这样一个假设：一个序列可能是另一个序列的祖先。在这种情况下，矩阵对氨基酸A替换为氨基酸B的评分可能与氨基酸B替换为氨基酸A的评分不同，因为进化路径可能不是对称的。非对称PAM矩阵适用于重建进化树或推断序列的进化关系。
### 应用上的不同
在应用上，对称PAM矩阵通常用于以下情况：
- 比对两个未知进化关系的蛋白质序列，以确定它们之间的相似性。
- 搜索数据库以找到与查询序列相似的序列。
非对称PAM矩阵则适用于以下情况：
- 建立蛋白质序列的进化树，推断它们的进化关系。
- 确定两个序列中的一个是否可能是另一个的祖先。
在实际使用中，选择哪种类型的PAM矩阵取决于研究的目的和背景。如果研究重点是比较序列之间的相似性，而不关心它们的进化历史，那么对称PAM矩阵就足够了。如果研究需要考虑序列的进化关系和方向，那么非对称PAM矩阵将是更合适的选择。




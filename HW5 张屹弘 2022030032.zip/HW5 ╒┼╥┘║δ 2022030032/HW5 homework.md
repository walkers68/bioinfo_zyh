# III.1 Mapping Homework
## 第一题  
bowtie利用了BWT的 last first mapping的特性来提高运行速度。  
bowtie使用了milestone和checkpoint两个策略来优化内存需求。
- milestone是指bowtie不会存储整个序列上每一个位点的信息，而是只存储其中一些的，在需要知道某个碱基的位置信息时通过向上或向下运算几次到milestone来计算其位置信息。
- checkpoint是指bowtie不会把每个碱基在序列中出现第几次全部记录，而是只记录部分，在使用时同样通过向上向下运算都已记录的碱基处计算得到结果。
## 第二题
生成.sam文件
```
bowtie -v 2 -m 10 --best --strata BowtieIndex/YeastGenome -f THA2.fa -S THA2.sam
```
![](第二题.png)
统计每条染色体上map了几条reads
```
grep -v "^@" THA2.sam | cut -f 3 | sort | uniq -c
```
![](第二题统计.png)
## 第三题
### 3.1
CIGAR全称是“Compact Idiosyncratic Gapped Alignment Report”，它以一种紧凑的方式描述了序列的比对情况，使得比对结果更加易于理解和分析。  
SAM（Sequence Alignment/Map）和 BAM（Binary Alignment/Map）是常用的存储测序数据和比对结果的文件格式。在这些文件中，每条比对记录都包含了一条序列比对的详细信息，其中就包括了 CIGAR 字符串。
CIGAR 字符串由一系列操作符和对应的长度组成，这些操作符包括：

- `M`：匹配或对齐的碱基。
- `I`：插入到参考序列中的碱基。
- `D`：从参考序列中删除的碱基。
- `N`：跳过参考序列的碱基。
- `S`：比对开始处剪切的碱基。
- `H`：比对结束处剪切的碱基。
- `P`：填充的碱基。
- `=`：匹配的碱基。
- `X`：不匹配的碱基。

通过解析 CIGAR 字符串，可以了解到序列比对的详细信息，包括匹配的位置、插入、删除等操作，从而更好地理解序列比对的结果。  
### 3.2
在序列比对中，“soft clip” 是指在比对过程中，一部分序列片段被忽略（剪切掉），但不影响比对结果。Soft clipping 通常发生在序列的两端，这些片段可能由于测序错误、低质量的碱基或者边界效应而导致无法完全匹配参考序列.  
在 CIGAR 字符串中，soft clipping 通过操作符`S`来表示。`S`操作符表示比对开始或结束处的序列片段被剪切掉了，但不会影响比对结果的计算。在 CIGAR 字符串中，`S`操作符后面跟着一个数字，表示被剪切掉的碱基的数量。  
例如，一个CIGAR字符串为`50M3S4M`，表示有50个匹配的碱基然后在比对开始处有3个碱基被softclip剪切掉了接着又有4个匹配的碱基。
### 3.3
reads 的 mapping quality（映射质量）是指比对算法对每个 reads 映射到参考基因组的可信度的度量。它反映了比对的置信水平，即比对结果的可靠程度。  
Mapping quality反映的信息包括：
1. **比对的准确性**：映射质量指示了比对算法对每个 reads 是否能够准确地将其放置到参考基因组上的位置。较高的映射质量表示比对结果更可信。

2. **重复性**：映射质量还可以反映比对的重复性。如果一个 reads 可以在参考基因组上的多个位置上找到匹配，那么它的映射质量可能会降低，因为比对算法无法确定最佳的匹配位置。

3. **比对的置信水平**：映射质量还可以用作评估比对结果的置信水平。较高的映射质量表示比对结果更可信，而较低的映射质量可能表明比对算法对于该 reads 的映射位置不太确信。
### 3.4
可以，通过 MD5 计算可以维一标识参考序列， 因为它基于序列本身而非其他信息，因而可以解决由于参考序列命名不同造成的歧义
## 第四题
建立索引
```
./bwa index ../share/sacCer3.fa
```
![](第四题建立索引.png)
mapping并存储文件
```
./bwa mem ../share/sacCer3.fa ../mapping/THA2.fa >> THA2-bwa.sam
```
![](第四题mapping.png)  
Mapping 结果：
[点击查看THA2-bwa.sam](THA2-bwa.sam)  
# III.1.1 Genome Browser Homework
FUN30 gene
![](FUN%2030基因.png)